# Flight Analytics
Flight Analytics with sparklyr and Python

<b>Related Content</b>:<br>
http://blog.cloudera.com/blog/2017/02/analyzing-us-flight-data-on-amazon-s3-with-sparklyr-and-apache-spark-2-0/
