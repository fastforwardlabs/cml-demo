# Flight Analytics
Flight Analytics with sparklyr and pyspark

Related Content
http://blog.cloudera.com/blog/2017/02/analyzing-us-flight-data-on-amazon-s3-with-sparklyr-and-apache-spark-2-0/
